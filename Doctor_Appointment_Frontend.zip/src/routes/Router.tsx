import { createBrowserRouter } from "react-router-dom";
import LandingPage from "@/pages/LandingPage";
import { ROUTES } from "@/constants/routes";
import Login from "@/pages/Login";
import {
  RedirectIfAuthenticated,
  RequirePatientAuth,
  RequireDoctorAuth,
} from "@/constants/AuthGate";

// Patient
import PatientLayout from "@/pages/PatientLayout";
import PatientDashboard from "@/pages/Patient/PatientDashboard";
import SearchDoctors from "@/pages/Patient/SearchDoctors";
import BookAppointment from "@/pages/Patient/BookAppointment";
import MyAppointments from "@/pages/Patient/MyAppointments";

// Doctor
import DoctorLayout from "@/pages/Doctor/DoctorLayout";
import DoctorDashboard from "@/pages/Doctor/DoctorDashboard";
import DoctorAppointments from "@/pages/Doctor/DoctorAppointments";
import DoctorSchedule from "@/pages/Doctor/DoctorSchedule";

const Router = createBrowserRouter([
  {
    path: ROUTES.HOME,
    element: <LandingPage />,
  },

  {
    Component: RedirectIfAuthenticated,
    children: [
      { path: ROUTES.LOGIN, Component: Login },
    ],
  },

  // ✅ PATIENT ROUTES
  {
    path: "/patient",
    Component: RequirePatientAuth,
    children: [
      {
        Component: PatientLayout,
        children: [
          { index: true, Component: PatientDashboard },
          { path: "search", Component: SearchDoctors },
          { path: "book/:doctorId", Component: BookAppointment },
          { path: "appointments", Component: MyAppointments },
        ],
      },
    ],
  },

  // ✅ DOCTOR ROUTES (added)
  {
    path: "/doctor",
    Component: RequireDoctorAuth,
    children: [
      {
        Component: DoctorLayout,
        children: [
          { index: true, Component: DoctorDashboard },
          { path: "appointments", Component: DoctorAppointments },
          { path: "schedule", Component: DoctorSchedule },
        ],
      },
    ],
  },
]);

export default Router;