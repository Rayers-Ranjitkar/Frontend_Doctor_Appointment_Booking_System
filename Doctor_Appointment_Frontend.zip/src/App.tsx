import Router from "@/routes/Router";
import { RouterProvider } from "react-router-dom";
import { AuthProvider } from "./constants/AuthContext";
import { ClinicProvider } from "./context/ClinicContext";

const App = () => {
  return (
    <AuthProvider>
      <ClinicProvider>
        <RouterProvider router={Router} />
      </ClinicProvider>
    </AuthProvider>
  );
};
export default App;
